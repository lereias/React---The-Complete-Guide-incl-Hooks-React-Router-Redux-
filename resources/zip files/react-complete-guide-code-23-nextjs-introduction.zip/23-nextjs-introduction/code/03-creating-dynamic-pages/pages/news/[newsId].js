// our-domain.com/news/something-important

function DetailPage() {
  return <h1>The Detail Page</h1>
}

export default DetailPage;