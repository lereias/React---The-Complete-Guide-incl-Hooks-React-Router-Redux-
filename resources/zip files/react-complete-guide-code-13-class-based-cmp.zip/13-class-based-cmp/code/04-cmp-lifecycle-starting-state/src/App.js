import UserFinder from './components/UserFinder';

function App() {
  return (
    <div>
      <UserFinder />
    </div>
  );
}

export default App;
