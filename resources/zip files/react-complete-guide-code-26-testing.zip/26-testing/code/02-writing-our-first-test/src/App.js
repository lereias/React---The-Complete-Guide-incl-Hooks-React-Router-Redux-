import Greeting from './components/Greeting';
import './App.css';

function App() {
  return (
    <div className='App'>
      <Greeting />
    </div>
  );
}

export default App;
