function Backdrop() {
  return <div className='backdrop' />;
}

export default Backdrop;
