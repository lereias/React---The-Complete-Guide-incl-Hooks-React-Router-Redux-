function NewMeetupPage() {
  return <div>New Meetup Page</div>;
}

export default NewMeetupPage;
